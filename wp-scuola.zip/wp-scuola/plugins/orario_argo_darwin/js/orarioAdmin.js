jQuery.noConflict();
(function($) {
	$(function() {  
	    $('#orario-tabelle-dati').tabs();
	});
})(jQuery);