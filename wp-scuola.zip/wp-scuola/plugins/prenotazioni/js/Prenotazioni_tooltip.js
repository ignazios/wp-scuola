jQuery.noConflict();
(function($) {
	$(function() {
		$('[data-toggle="tooltip"]').tooltip();
	});
});
	